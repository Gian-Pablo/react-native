import React from 'react';
import { Text, View, Button } from 'react-native';

const MINIMUM = 2;
const MAXIMUM = 30;

export default function Counter({ valor, setValor }) {
  return (
    <View style={{flexDirection: 'row', alignItems: 'center'}}>
      <Button title="-" onPress={() => setValor((v) => Math.max(v - 1, MINIMUM))} />
      <Text style={{flex: 1, textAlign: 'center', fontSize: 21}}>{valor}</Text>
      <Button title="+" onPress={() => setValor((v) => Math.min(v + 1, MAXIMUM))} />
    </View>
  );
}
import { View, Text } from 'react-native';

function leftPad(str, len, ch='0') {
  const strLen = str.length;

  if (strLen < len) {
    return ch.repeat(len - strLen) + str;
  } else {
    return str;
  }
}

export default function Timer({ time }) {
  let minuto;
  let segundo;

  minuto = Math.floor(time / 60);
  segundo = time % 60;

  minuto = leftPad(minuto.toString(), 2, '0');
  segundo = leftPad(segundo.toString(), 2, '0');

  const display = minuto + ":" + segundo

  return (
    <View>
      <Text style={{fontSize: 24, marginTop: 21}}>{display}</Text>
    </View>
  )
}
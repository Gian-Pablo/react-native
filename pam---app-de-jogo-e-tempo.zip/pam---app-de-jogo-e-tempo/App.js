import { View, Text, SafeAreaView, StyleSheet, Button } from 'react-native';
import { useState, useEffect } from 'react';
import Timer from './components/Timer';
import Counter from './components/Counter';

const TRINTA_MINUTOS = 30*60;

function leftPad(str, len, ch='0') {
  const strLen = str.length;

  if (strLen < len) {
    return ch.repeat(len - strLen) + str;
  } else {
    return str;
  }
}

function formatCurrency(valor) {
  valor = Math.floor(valor * 100);
  const reais = Math.floor(valor / 100);
  const centavos = valor % 100;

  const formattedCentavos = leftPad(centavos.toString(), 2);

  return `R\$${reais},${formattedCentavos}`;
}


export default function App() {
  const [timer, setTimer] = useState(2);
  const [cost, setCost] = useState(0);
  const [incr, setIncr] = useState(2);
  const addTime = (time, custo) => {
    setTimer((cur) => Math.min(cur + time, TRINTA_MINUTOS));
    setCost((cur) => cur + custo);
  }

  // Timer logic
  useEffect(() => {
    const interval = setInterval(() => {
      if (timer > 0) {
        setTimer((time) => time - 1);
      }

    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  let desconto = Math.floor((incr-2)/10);
  let preco;
  preco = 1.5*(incr - 2)+5;
  preco = preco * (1 - desconto * 0.05); // adicionar 5% de desconto, a cada 10 minutos adicionados
  const precoDisplay = formatCurrency(preco);

  return (
    <SafeAreaView style={{marginTop: 64, width: '100%', alignItems: 'center'}}>
      <View style={{gap: 4}}>
        <Button title="1 minuto - R$3,00"  color='lime' onPress={() => addTime(60, 3)} />
        <Button title="2 minutos - R$5,00" color='green' onPress={() => addTime(120, 5)} />
        <View style={{marginBottom: 8}} />
        <Counter valor={incr} setValor={setIncr} />
        <Button title={`Adicionar mais minutos por ${precoDisplay}`} color='rgb(31, 81, 255)' onPress={() => addTime(incr * 60, preco)} />
      </View>
      <Timer time={timer} />
      <Text style={{marginTop: 40, fontSize: 17, textAlign: 'center'}}>
        {timer <= 0 ? `Seu Tempo Acabou!                                             Seu gasto no jogo VR foi de ${formatCurrency(cost)}` : ''}
      </Text>

    </SafeAreaView>
  );
}

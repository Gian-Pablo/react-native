import { Text, SafeAreaView, Button } from 'react-native';
import { useState } from 'react';
import App from './App';
   
function Welcome({ setIsApp }) {
  return (
    <SafeAreaView style={{marginTop: 64, marginBlock: 16, alignItems: 'center', width: '100%'}}>
      <Text style={{fontSize: 30, marginBottom: 5, fontWeight: 500}}>Joguinho VR</Text>
      <Text style={{fontSize: 25, marginBottom: 37, fontWeight: 400}}>(Virtual Reality)</Text>
      <Button title="Começar" color="blue" onPress={() => setIsApp(true)} />
    </SafeAreaView>
  )
}

export default function Main() {
  const [isApp, setIsApp] = useState(false);

  return (
    isApp ? <App /> : <Welcome setIsApp={setIsApp} />
  );
}
